from django.apps import AppConfig


class ParticipantsConfig(AppConfig):
    name = 'participants'
